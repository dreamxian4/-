#include<spider.h>

int main(){
	char* url="https://baike.baidu.com/item/%E5%8E%9F%E7%A5%9E/23583622?fr=aladdin";
	Spider_Controler(url);
	return 0;
}
