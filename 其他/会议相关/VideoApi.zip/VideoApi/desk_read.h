#ifndef DESK_READ_H
#define DESK_READ_H

#include <QObject>

class Desk_Read : public QObject
{
    Q_OBJECT
public:
    explicit Desk_Read(QObject *parent = nullptr);

signals:

};

#endif // DESK_READ_H
