#include "desk_read.h"

Desk_Read::Desk_Read(QObject *parent) : QObject(parent)
{

}
